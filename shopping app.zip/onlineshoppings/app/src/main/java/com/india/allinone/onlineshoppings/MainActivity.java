package com.india.allinone.onlineshoppings;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.widget.Toast;

import com.india.allinone.onlineshoppings.Amapters.RecipeAdapter;
import com.india.allinone.onlineshoppings.Classes.RecyclerItemClickListener;
import com.india.allinone.onlineshoppings.models.RecipeModel;

import java.util.ArrayList;

public class MainActivity extends AppCompatActivity {

    RecyclerView recyclerView;

    String[] urls=new String[42];

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        recyclerView = findViewById(R.id.recyclarview);

        ArrayList<RecipeModel> list = new ArrayList<>();

        list.add(new RecipeModel(R.drawable.amazon, "Amazon"));
        list.add(new RecipeModel(R.drawable.flipkart, "Flipkart"));
        list.add(new RecipeModel(R.drawable.myntra, "Myntra"));
        list.add(new RecipeModel(R.drawable.walmart, "Walmart"));
        list.add(new RecipeModel(R.drawable.tatacliq, "Tatacliq"));
        list.add(new RecipeModel(R.drawable.ebay, "ebay"));
        list.add(new RecipeModel(R.drawable.pepperfry, "Pepperfry"));
        list.add(new RecipeModel(R.drawable.paytmmall, "Paytmmall"));
        list.add(new RecipeModel(R.drawable.alibaba, "Alibaba"));
        list.add(new RecipeModel(R.drawable.target, "Target"));
        list.add(new RecipeModel(R.drawable.nykaa, "Nykaa"));
        list.add(new RecipeModel(R.drawable.bestbuy, "Bestbuy"));
        list.add(new RecipeModel(R.drawable.ikea, "Ikea"));
        list.add(new RecipeModel(R.drawable.firstcry, "Firstcry"));
        list.add(new RecipeModel(R.drawable.mg, "1mg"));
        list.add(new RecipeModel(R.drawable.ajio, "ajio"));
        list.add(new RecipeModel(R.drawable.bigbasket, "bigbasket"));
        list.add(new RecipeModel(R.drawable.grofers, "grofers"));
        list.add(new RecipeModel(R.drawable.gud, "2gud"));
        list.add(new RecipeModel(R.drawable.shopclus, "Shopclus"));
        list.add(new RecipeModel(R.drawable.shop, "Shop"));
        list.add(new RecipeModel(R.drawable.groupon, "Groupon"));
        list.add(new RecipeModel(R.drawable.makemyttrip, "Makemyttrip"));
        list.add(new RecipeModel(R.drawable.bookmyshow, "Bookmyshow"));
        list.add(new RecipeModel(R.drawable.koovs, "Koovs"));
        list.add(new RecipeModel(R.drawable.fnp, "FNP"));
        list.add(new RecipeModel(R.drawable.lenskart, "Lenskart"));
        list.add(new RecipeModel(R.drawable.bewakoof, "Bewakoof"));
        list.add(new RecipeModel(R.drawable.limeroad, "Limeroad"));
        list.add(new RecipeModel(R.drawable.netmeds, "Netmeds"));
        list.add(new RecipeModel(R.drawable.maxfashion, "Maxfashion"));
        list.add(new RecipeModel(R.drawable.brandfactoryonline, "Brand Factory"));
        list.add(new RecipeModel(R.drawable.healthkart, "Healthkart"));
        list.add(new RecipeModel(R.drawable.pharmeasy, "Pharmeasy"));
        list.add(new RecipeModel(R.drawable.puma, "Puma"));
        list.add(new RecipeModel(R.drawable.croma, "Croma"));
        list.add(new RecipeModel(R.drawable.indiamart, "Indiamart"));
        list.add(new RecipeModel(R.drawable.adidas, "Adidas"));
        list.add(new RecipeModel(R.drawable.nike, "Nike"));
        list.add(new RecipeModel(R.drawable.clovia, "Clovia"));
        list.add(new RecipeModel(R.drawable.bata, "Bata"));
        list.add(new RecipeModel(R.drawable.medlife, "Medlife"));

        RecipeAdapter adapter = new RecipeAdapter(list,this);
        recyclerView.setAdapter(adapter);

        GridLayoutManager gridLayoutManager = new GridLayoutManager(this, 2);
        recyclerView.setLayoutManager(gridLayoutManager);


        urls[0]="https://www.flipkart.com/?affid=sidgutgmai&affExtParam1=dhr429276508_60b45752cf7be8837_65&affExtParam2=inrdeals";
        urls[1]="https://www.amazon.in?&linkCode=ll2&tag=dhruvpatel0a-21&linkId=2d65c73aba6f3d5894042bdc73455c94&language=en_IN&ref_=as_li_ss_tl";
        urls[2]="https://www.myntra.com/?utm_source=optimise&utm_medium=affiliate&utm_campaign=355300_dhr429276508_60b8cf3629aec6995_193&sskey=9835c73e2b0d4efb9242e6ef872aef86";
        urls[3]="https://www.walmart.com/";
        urls[4]="https://www.tatacliq.com/?cid=af:homepage:inrdeals:hasoffers:15032017";
        urls[5]="https://www.ebay.com/";
        urls[6]="https://www.pepperfry.com/?utm_source=inrdeals&utm_medium=referral&utm_campaign=offer-remarketing&utm_term=remarketing";
        urls[7]="https://paytmmall.com/";
        urls[8]="https://www.alibaba.com/";
        urls[9]="https://www.target.com/";
        urls[10]="https://www.nykaa.com/";
        urls[11]="https://www.bestbuy.com/";
        urls[12]="https://www.ikea.com/";
        urls[13]="https://www.firstcry.com/?ref=OMG1_355300&utm_source=OMG1&utm_medium=aff&utm_content=OMG1_dhr429276508_60b8d1313c6917643_63";
        urls[14]="https://www.1mg.com/?utm_source=offline&utm_medium=inrdeals&utm_campaign=june_dhr429276508_60b8d156dda162289_2";
        urls[15]="https://www.ajio.com/?utm_source=OMG&utm_medium=Affiliate&utm_content=launch&utm_campaign=355300_dhr429276508_60b8d17341e8b6989_10";
        urls[16]="https://www.bigbasket.com/";
        urls[17]="https://grofers.com/";
        urls[18]="https://www.2gud.com/";
        urls[19]="https://www.shopclues.com/";
        urls[20]="https://www.shop.com/";
        urls[21]="https://www.groupon.com/";
        urls[22]="https://www.makemytrip.com/hotels/?cmp=disp_omg_DH&source=355300_dhr429276508_60b8d31476b942319_431";
        urls[23]="https://in.bookmyshow.com/";
        urls[24]="https://www.koovs.com/?utm_source=tradetracker&utm_medium=affiliate&utm_campaign=cps-353671-dhr429276508-60b8d363d25f58764-129";
        urls[25]="https://www.fnp.com/?utm_source=affiliate&utm_medium=Banner&utm_campaign=omg_355300_dhr429276508_60b8d3876f8186630_247";
        urls[26]="https://www.lenskart.com/";
        urls[27]="https://www.bewakoof.com/?~campaign=admitad_test&~channel=admitad&~feature=paid%20advertising&$desktop_url=https://www.bewakoof.com&$fallback_url=https://www.bewakoof.com&$deeplink_path=www.bewakoof.com&utm_source=admitad&utm_medium=affiliate&utm_campaign=admitad_test&%243p=a_admitad&~click_id=2e3cf68c56707ad7657ccc720a59d62b&~secondary_publisher=401684";
        urls[28]="https://www.limeroad.com/?utm_source=affiliates&utm_medium=inrdeals&utm_campaign=dhr429276508_60b8d400e39366739_348";
        urls[29]="https://www.netmeds.com/?source_attribution=COCNIC-CPS&utm_campaign=COCNIC-CPS&utm_medium=CPS&utm_source=COCNIC-CPS";
        urls[30]="https://www.maxfashion.in/in/en/";
        urls[31]="https://www.brandfactoryonline.com/";
        urls[32]="https://inr.deals/track?id=dhr429276508&src=merchant-detail-backend&campaign=cps&url=https%3A%2F%2Fwww.healthkart.com%2F";
        urls[33]="https://pharmeasy.in/?utm_source=aff-optimise&utm_medium=cpft&utm_campaign=355300_dhr429276508_60b8d8ccc10136658_1611&code=VG18";
        urls[34]="https://in.puma.com/in/en/home?utm_medium=AFF&utm_source=OTH-CPO&utm_aud=MULT&utm_obj=OLC&utm_campaign=AFF_OTH_CPO_MULT_OLC_AdmitAd_b7a0d319d6238f2e13e52879840a5fa8_401684_";
        urls[35]="https://www.croma.com/?utm_source=omg&utm_medium=affiliates&utm_campaign=355300_dhr429276508_60b8d914f0c569557_316";
        urls[36]="https://www.indiamart.com/";
        urls[37]="https://shop.adidas.co.in/?utm_source=omg&utm_medium=SPC_355300&utm_campaign=355300_dhr429276508_60b8d95ad0aa24932_7";
        urls[38]="https://www.nike.com/in/?cp=76060516106_aff_|8WD*rW8tVwE|&ranMID=41134&ranEAID=8WD*rW8tVwE&ranSiteID=8WD.rW8tVwE-WiAi5Py24sT39XhwCq3OBA";
        urls[39]="https://www.clovia.com/bras/4-for-499/s/?utm_source=10347&utm_medium=20025&utm_campaign=90798_1201";
        urls[40]="https://www.bata.com/";
        urls[41]="https://www.medlife.com/";

        recyclerView.addOnItemTouchListener(new RecyclerItemClickListener
                (this, recyclerView, new RecyclerItemClickListener.OnItemClickListener() {
                    @Override
                    public void onItemClick(View view, int position) {
                        switch (position){
                            case 0:
                                Intent intent = new Intent(getApplicationContext(), Webview.class);
                                intent.putExtra("links",urls[1]);
                                startActivity(intent);
                                break;

                            case 1:
                                Toast.makeText(MainActivity.this, "this is flipkart", Toast.LENGTH_SHORT).show();
                                break;
                            case 2:
                                intent = new Intent(getApplicationContext(),Webview.class);
                                intent.putExtra("links",urls[2]);
                                startActivity(intent);
                                break;
                            case 3:
                                intent = new Intent(getApplicationContext(), Webview.class);
                                intent.putExtra("links",urls[3]);
                                startActivity(intent);
                                break;
                            case 4:
                                intent = new Intent(getApplicationContext(), Webview.class);
                                intent.putExtra("links",urls[4]);
                                startActivity(intent);
                                break;
                            case 5:
                                intent = new Intent(getApplicationContext(), Webview.class);
                                intent.putExtra( "links", urls[5]);
                                startActivity(intent);
                                break;
                            case 6:
                                intent = new Intent(getApplicationContext(), Webview.class);
                                intent.putExtra( "links", urls[6]);
                                startActivity(intent);
                                break;
                            case 7:
                                intent = new Intent(getApplicationContext(), Webview.class);
                                intent.putExtra( "links", urls[7]);
                                startActivity(intent);
                                break;
                            case 8:
                                intent = new Intent(getApplicationContext(), Webview.class);
                                intent.putExtra( "links", urls[8]);
                                startActivity(intent);
                                break;
                            case 9:
                                intent = new Intent(getApplicationContext(), Webview.class);
                                intent.putExtra( "links", urls[9]);
                                startActivity(intent);
                                break;
                            case 10:
                                intent = new Intent(getApplicationContext(), Webview.class);
                                intent.putExtra( "links", urls[10]);
                                startActivity(intent);
                                break;
                            case 11:
                                intent = new Intent(getApplicationContext(), Webview.class);
                                intent.putExtra( "links", urls[11]);
                                startActivity(intent);
                                break;

                            case 12:
                                intent = new Intent(getApplicationContext(), Webview.class);
                                intent.putExtra("links",urls[12]);
                                startActivity(intent);
                                break;
                            case 13:
                                intent = new Intent(getApplicationContext(), Webview.class);
                                intent.putExtra("links",urls[13]);
                                startActivity(intent);
                                break;
                            case 14:
                                intent = new Intent(getApplicationContext(), Webview.class);
                                intent.putExtra("links",urls[14]);
                                startActivity(intent);
                                break;
                            case 15:
                                intent = new Intent(getApplicationContext(), Webview.class);
                                intent.putExtra("links",urls[15]);
                                startActivity(intent);
                                break;
                            case 16:
                                intent = new Intent(getApplicationContext(), Webview.class);
                                intent.putExtra( "links", urls[16]);
                                startActivity(intent);
                                break;
                            case 17:
                                intent = new Intent(getApplicationContext(), Webview.class);
                                intent.putExtra( "links", urls[17]);
                                startActivity(intent);
                                break;
                            case 18:
                                intent = new Intent(getApplicationContext(), Webview.class);
                                intent.putExtra( "links", urls[18]);
                                startActivity(intent);
                                break;
                            case 19:
                                intent = new Intent(getApplicationContext(), Webview.class);
                                intent.putExtra( "links", urls[19]);
                                startActivity(intent);
                                break;
                            case 20:
                                intent = new Intent(getApplicationContext(), Webview.class);
                                intent.putExtra( "links", urls[20]);
                                startActivity(intent);
                                break;
                            case 21:
                                intent = new Intent(getApplicationContext(), Webview.class);
                                intent.putExtra( "links", urls[21]);
                                startActivity(intent);
                                break;
                            case 22:
                                intent = new Intent(getApplicationContext(), Webview.class);
                                intent.putExtra( "links", urls[22]);
                                startActivity(intent);
                                break;

                            case 23:
                                intent = new Intent(getApplicationContext(), Webview.class);
                                intent.putExtra("links",urls[23]);
                                startActivity(intent);
                                break;
                            case 24:
                                intent = new Intent(getApplicationContext(), Webview.class);
                                intent.putExtra("links",urls[24]);
                                startActivity(intent);
                                break;
                            case 25:
                                intent = new Intent(getApplicationContext(), Webview.class);
                                intent.putExtra("links",urls[25]);
                                startActivity(intent);
                                break;
                            case 26:
                                intent = new Intent(getApplicationContext(), Webview.class);
                                intent.putExtra("links",urls[26]);
                                startActivity(intent);
                                break;
                            case 27:
                                intent = new Intent(getApplicationContext(), Webview.class);
                                intent.putExtra( "links", urls[27]);
                                startActivity(intent);
                                break;
                            case 28:
                                intent = new Intent(getApplicationContext(), Webview.class);
                                intent.putExtra( "links", urls[28]);
                                startActivity(intent);
                                break;
                            case 29:
                                intent = new Intent(getApplicationContext(), Webview.class);
                                intent.putExtra( "links", urls[29]);
                                startActivity(intent);
                                break;
                            case 30:
                                intent = new Intent(getApplicationContext(), Webview.class);
                                intent.putExtra( "links", urls[30]);
                                startActivity(intent);
                                break;
                            case 31:
                                intent = new Intent(getApplicationContext(), Webview.class);
                                intent.putExtra( "links", urls[31]);
                                startActivity(intent);
                                break;
                            case 32:
                                intent = new Intent(getApplicationContext(), Webview.class);
                                intent.putExtra( "links", urls[32]);
                                startActivity(intent);
                                break;
                            case 33:
                                intent = new Intent(getApplicationContext(), Webview.class);
                                intent.putExtra( "links", urls[33]);
                                startActivity(intent);
                                break;
                            case 34:
                                intent = new Intent(getApplicationContext(), Webview.class);
                                intent.putExtra("links",urls[34]);
                                startActivity(intent);
                                break;
                            case 35:
                                intent = new Intent(getApplicationContext(), Webview.class);
                                intent.putExtra("links",urls[35]);
                                startActivity(intent);
                                break;
                            case 36:
                                intent = new Intent(getApplicationContext(), Webview.class);
                                intent.putExtra( "links", urls[36]);
                                startActivity(intent);
                                break;
                            case 37:
                                intent = new Intent(getApplicationContext(), Webview.class);
                                intent.putExtra( "links", urls[37]);
                                startActivity(intent);
                                break;
                            case 38:
                                intent = new Intent(getApplicationContext(), Webview.class);
                                intent.putExtra( "links", urls[38]);
                                startActivity(intent);
                                break;
                            case 39:
                                intent = new Intent(getApplicationContext(), Webview.class);
                                intent.putExtra( "links", urls[39]);
                                startActivity(intent);
                                break;
                            case 40:
                                intent = new Intent(getApplicationContext(), Webview.class);
                                intent.putExtra( "links", urls[40]);
                                startActivity(intent);
                                break;
                            case 41:
                                intent = new Intent(getApplicationContext(), Webview.class);
                                intent.putExtra( "links", urls[41]);
                                startActivity(intent);
                                break;
                            default:
                        }
                    }

                    @Override
                    public void onLongItemClick(View view, int position) {

                    }
                }

                ));

        //        LinearLayoutManager layoutManager = new LinearLayoutManager(this);
//        recyclerView.setLayoutManager(layoutManager);

//        LinearLayoutManager layoutManager = new LinearLayoutManager(this, LinearLayoutManager.HORIZONTAL, true);
//        recyclerView.setLayoutManager(layoutManager);


    }
    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        MenuInflater inflater =     getMenuInflater();
        inflater.inflate(R.menu.menu, menu);
        return true;
    }

    @SuppressLint("NonConstantResourceId")
    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {
        switch (item.getItemId()){
            case R.id.search_icon:
                Intent intent = new Intent(getApplicationContext(), Webview.class);
                intent.putExtra( "links", "https://qmamu.com/");
                startActivity(intent);
                break;
            case R.id.share_icon:
                Intent shareIntent =   new Intent(android.content.Intent.ACTION_SEND);
                shareIntent.setType("text/plain");
                shareIntent.putExtra(Intent.EXTRA_SUBJECT,"Insert Subject here");
                String app_url = " https://play.google.com/store/apps/details?id=com.social.messenger.allinoneapps&hl=en";
                shareIntent.putExtra(android.content.Intent.EXTRA_TEXT,app_url);
                startActivity(Intent.createChooser(shareIntent, "Share via"));
                break;
//            case R.id.information:
//                Toast.makeText(this, "information", Toast.LENGTH_SHORT).show();
//                break;
            case R.id.privacy:
                intent = new Intent(getApplicationContext(), Webview.class);
                intent.putExtra( "links", "https://oxobrowser.com/Privacy.php");
                startActivity(intent);
                Toast.makeText(this, "App privacy", Toast.LENGTH_SHORT).show();
                break;
        }
        return super.onOptionsItemSelected(item);
    }
}