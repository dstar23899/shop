package com.india.allinone.onlineshoppings;

import android.app.Application;

public class one_signal extends Application {
    private static final String ONESIGNAL_APP_ID = "8c7698fe-66e3-468e-a414-332ff3cd4ec6";


    @Override
    public void onCreate() {
        super.onCreate();

        // OneSignal Initialization
//        OneSignal.initWithContext(this);
//        OneSignal.setAppId(ONESIGNAL_APP_ID);
    }
}
